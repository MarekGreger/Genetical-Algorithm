var searchData=
[
  ['krzyzowanie_0',['Krzyzowanie',['../class_operacje.html#a947d03f24ba39982999960763826e766',1,'Operacje']]]
];
