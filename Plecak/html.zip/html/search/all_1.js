var searchData=
[
  ['cena_0',['Cena',['../struct_obiekt.html#a55412c4f2c06a6c8b8bb411e13fc1479',1,'Obiekt']]],
  ['chromosom_1',['Chromosom',['../class_osobnik.html#ab62fe567a0c425837056d6a844f753bb',1,'Osobnik']]]
];
