var searchData=
[
  ['pojemnosc_0',['Pojemnosc',['../class_osobnik.html#a62f150e1ebff82f1c84cec3cbc598038',1,'Osobnik']]]
];
