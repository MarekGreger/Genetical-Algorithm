var searchData=
[
  ['zero_0',['zero',['../class_osobnik.html#a08143bf9a3a21cefe084cd263fcf2965',1,'Osobnik']]]
];
