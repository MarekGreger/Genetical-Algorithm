var searchData=
[
  ['źródło_2ecpp_0',['Źródło.cpp',['../_xC5_xB9r_xC3_xB3d_xC5_x82o_8cpp.html',1,'']]]
];
