var searchData=
[
  ['obiekt_0',['Obiekt',['../struct_obiekt.html',1,'']]],
  ['operacje_1',['Operacje',['../class_operacje.html',1,'']]],
  ['osobnik_2',['Osobnik',['../class_osobnik.html',1,'']]]
];
