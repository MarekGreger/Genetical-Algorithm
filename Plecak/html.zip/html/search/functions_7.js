var searchData=
[
  ['zapis_0',['Zapis',['../class_operacje.html#a467f5ccf9d691d003af0a21c0bcfc3dd',1,'Operacje']]]
];
