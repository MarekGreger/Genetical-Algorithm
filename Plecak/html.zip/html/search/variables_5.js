var searchData=
[
  ['waga_0',['Waga',['../struct_obiekt.html#a4ca3ea51ca5c7ac913890225ede93667',1,'Obiekt']]],
  ['wynik_1',['Wynik',['../class_osobnik.html#afcc83d1009e673482ed138af037b8e74',1,'Osobnik']]]
];
