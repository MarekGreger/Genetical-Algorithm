var indexSectionsWithContent =
{
  0: "acgiklmopswz~ź",
  1: "o",
  2: "opwź",
  3: "agkmoswz~",
  4: "cilpswz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Pliki",
  3: "Funkcje",
  4: "Zmienne"
};

