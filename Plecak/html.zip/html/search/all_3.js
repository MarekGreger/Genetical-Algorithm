var searchData=
[
  ['ile_0',['ile',['../class_osobnik.html#af044959ead4707461da652cb24575486',1,'Osobnik']]],
  ['iteracja_1',['iteracja',['../class_osobnik.html#afca23690421cec478f2e7c2e85092ee0',1,'Osobnik']]]
];
