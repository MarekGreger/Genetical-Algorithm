var searchData=
[
  ['wczytanie_5fdanych_0',['Wczytanie_danych',['../_wczytywanie___danych_8cpp.html#a63b2156368019daf9c4c8a56f6d3c44f',1,'Wczytanie_danych(const std::string &amp;nazwapliku, std::vector&lt; Obiekt &gt; &amp;dane):&#160;Wczytywanie_Danych.cpp'],['../_wczytywanie___danych_8h.html#a63b2156368019daf9c4c8a56f6d3c44f',1,'Wczytanie_danych(const std::string &amp;nazwapliku, std::vector&lt; Obiekt &gt; &amp;dane):&#160;Wczytywanie_Danych.cpp']]],
  ['wczytywanie_5fobiektow_1',['Wczytywanie_Obiektow',['../class_operacje.html#a7acad4e5cc331d64c511aa97678e16a8',1,'Operacje']]],
  ['wyswietl_5fchromosom_2',['Wyswietl_Chromosom',['../class_osobnik.html#a36ac8878b3704aa6d7ad1f1d457863a2',1,'Osobnik']]],
  ['wyswietl_5fpopulacje_3',['Wyswietl_Populacje',['../class_operacje.html#a218b7b0406a08bb40c0fc9f153c383ba',1,'Operacje']]],
  ['wyswietl_5fwynik_4',['Wyswietl_Wynik',['../class_osobnik.html#a8c7ee0661299a067ebbc40164ed141e9',1,'Osobnik']]]
];
