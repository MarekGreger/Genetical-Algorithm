var searchData=
[
  ['generowanie_5fosobnika_0',['Generowanie_Osobnika',['../class_osobnik.html#a80b9c696d8fb8cd18dfb87c9362d543a',1,'Osobnik']]],
  ['generowanie_5fpopulacji_1',['Generowanie_Populacji',['../class_operacje.html#afda383d0ed7fe289c382470240831903',1,'Operacje']]],
  ['get_5file_2',['Get_ile',['../class_operacje.html#a02434d67498804b32c9311a64cf7f080',1,'Operacje']]],
  ['get_5fpojemnosc_3',['Get_Pojemnosc',['../class_osobnik.html#ace2e26b77ffe5fdf0876051155e8aa8d',1,'Osobnik']]],
  ['get_5fsumaryczna_5fcena_4',['Get_Sumaryczna_cena',['../class_osobnik.html#ad81a8f6bfa28032ac463fe0f806326a7',1,'Osobnik']]],
  ['get_5fwynik_5',['Get_Wynik',['../class_osobnik.html#ac8ae9c3469c0d60f831a4e2d1bda9f1a',1,'Osobnik']]]
];
