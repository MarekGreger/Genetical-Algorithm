var searchData=
[
  ['plecak_2ecpp_0',['Plecak.cpp',['../_plecak_8cpp.html',1,'']]]
];
