var searchData=
[
  ['sprawdzajacy_0',['sprawdzajacy',['../class_operacje.html#a5195e6f47f0bfeb76f2b8288e7dc0acc',1,'Operacje']]],
  ['sumaryczna_5fcena_1',['Sumaryczna_cena',['../class_osobnik.html#ab436922c693c7a620974a1fb3e448ca7',1,'Osobnik']]]
];
