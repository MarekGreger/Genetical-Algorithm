var searchData=
[
  ['licznik_0',['licznik',['../class_osobnik.html#ad731131d1c66bab2ccfd84cc02e79d99',1,'Osobnik']]]
];
