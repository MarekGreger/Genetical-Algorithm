var searchData=
[
  ['aktualizuj_5fdane_0',['Aktualizuj_Dane',['../class_osobnik.html#aee68882d4c36a58946aed16a2a655f47',1,'Osobnik']]]
];
