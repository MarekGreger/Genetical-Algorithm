var searchData=
[
  ['zapis_0',['Zapis',['../class_operacje.html#a467f5ccf9d691d003af0a21c0bcfc3dd',1,'Operacje']]],
  ['zero_1',['zero',['../class_osobnik.html#a08143bf9a3a21cefe084cd263fcf2965',1,'Osobnik']]]
];
