var searchData=
[
  ['selekcja_0',['Selekcja',['../class_operacje.html#ac16ee9d05d6d251f78025e3e279fb677',1,'Operacje']]],
  ['set_5file_1',['Set_ile',['../class_operacje.html#a93e016c3cf5f42a89ba8fa24a21c6f1f',1,'Operacje']]],
  ['set_5fwynik_2',['Set_Wynik',['../class_osobnik.html#af13de080b8e75999a7bf41c3565768f8',1,'Osobnik']]],
  ['sprawdzajacy_3',['sprawdzajacy',['../class_operacje.html#a5195e6f47f0bfeb76f2b8288e7dc0acc',1,'Operacje']]],
  ['sumaryczna_5fcena_4',['Sumaryczna_cena',['../class_osobnik.html#ab436922c693c7a620974a1fb3e448ca7',1,'Osobnik']]]
];
