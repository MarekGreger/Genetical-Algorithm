var searchData=
[
  ['_7eoperacje_0',['~Operacje',['../class_operacje.html#a1cb6751678acceef89188d6299095b4a',1,'Operacje']]],
  ['_7eosobnik_1',['~Osobnik',['../class_osobnik.html#aff739292c0bf06166c74bcc959f9e6fe',1,'Osobnik']]]
];
