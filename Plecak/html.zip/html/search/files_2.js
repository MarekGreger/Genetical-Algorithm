var searchData=
[
  ['wczytywanie_2ecpp_0',['Wczytywanie.cpp',['../_wczytywanie_8cpp.html',1,'']]],
  ['wczytywanie_5fdanych_2ecpp_1',['Wczytywanie_Danych.cpp',['../_wczytywanie___danych_8cpp.html',1,'']]],
  ['wczytywanie_5fdanych_2eh_2',['Wczytywanie_Danych.h',['../_wczytywanie___danych_8h.html',1,'']]]
];
